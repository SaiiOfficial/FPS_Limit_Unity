Created by Saiiofficial
Come to my Discord if you have any problems!
Discord-Server = https://discord.gg/KEJve7cVHt
Discord-Tag = AQT saiiofficial#7453
Last update on 03/17/2022

1. unpack
- Unpack with 7 Zip or other software.

2. Import into Unity
- Import the script into Unity using drag and drop.

3. Create a GameObject
- Right-click in the hierarchy.
- Then press Create Empty.

4. Rename the GameObject to FPSLimit
- Right click on the GameObject.
- Then press Rename and name it FPSLimit.

5. Drag and drop the script onto the GameObject.

And the FPSLimit is done!