// Created by Saiiofficial
// Come to my Discord if you have any problems!
// Discord-Server = https://discord.gg/KEJve7cVHt
// Discord-Tag = AQT saiiofficial#7453
// Last update on 03/17/2022

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FPSLimit : MonoBehaviour
{

    void Start()
    {
        Application.targetFrameRate = 60;
    }

}